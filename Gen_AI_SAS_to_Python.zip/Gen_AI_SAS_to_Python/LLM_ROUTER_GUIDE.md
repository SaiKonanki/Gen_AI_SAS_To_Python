# LLM Router Guide

## Overview

The **LLM Router** is an intelligent system that automatically selects the best AI model to convert your SAS code to Python based on code complexity, cost, speed, and quality requirements.

---

## 🤖 Providers & Models

### What is the relationship between Groq and Llama?

- **Groq**: A hardware company that builds ultra-fast AI inference chips (LPUs - Language Processing Units)
- **Llama**: A family of open-source large language models developed by Meta (Facebook)
- **Groq + Llama**: Groq provides API access to Llama models hosted on their specialized hardware, offering extremely fast inference speeds

**Think of it this way:**
- **Llama** = The AI brain (the model)
- **Groq** = The superfast computer running the brain (the infrastructure)

---

## 📊 Supported Providers

| Provider | Company | Model Family | Strengths |
|----------|---------|--------------|-----------|
| **Anthropic** | Anthropic | Claude | Highest quality, best for complex logic |
| **OpenAI** | OpenAI | GPT | Balanced quality and speed |
| **Groq** | Meta (via Groq) | Llama | Fastest inference, cost-effective |

---

## 🎯 Available Models

### Anthropic (Claude)
- **`claude-3-haiku-20240307`**: Fast, cost-effective for simple tasks
- **`claude-3-5-sonnet-20241022`**: Advanced reasoning for complex SAS code

### OpenAI (GPT)
- **`gpt-4o-mini`**: Fast and cheap, good for simple conversions
- **`gpt-4o`**: High quality, strong at complex logic and macros

### Groq (Llama)
- **`llama-3.1-8b-instant`**: Ultra-fast, 8 billion parameters
- **`llama-3.1-70b-versatile`**: Larger model (70B params), better quality

---

## 🧮 Complexity Analysis

The router analyzes your SAS code and assigns a **complexity score (0-10)** based on:

| Factor | Weight | Examples |
|--------|--------|----------|
| **Hard Features** | +5 | `%MACRO`, `PROC TRANSPOSE`, `PROC FCMP` |
| **Macro Usage** | +1 to +3 | `%LET`, `%DO`, macro variables |
| **Code Length** | +1 to +3 | 50+ lines = medium, 150+ = hard |
| **SQL Complexity** | +1 to +2 | Multiple JOINs, subqueries, CASE statements |
| **Data Operations** | +1 to +2 | `MERGE`, `RETAIN`, `LAG()`, `FIRST./LAST.` |
| **Control Flow** | +1 to +2 | Many `IF` statements, `DO` loops |
| **Arrays** | +1 | `ARRAY` usage |

### Complexity Levels
- **0-3**: 🟢 **Easy** - Simple DATA steps, basic PROC PRINT
- **4-7**: 🟡 **Medium** - PROC SQL with JOINs, moderate macros
- **8-10**: 🔴 **Hard** - Complex macros, nested logic, advanced procs

---

## 🎛️ Routing Strategies

You can choose from 4 routing strategies in the UI:

### 1. **Balanced** (Recommended)
Optimizes for cost, speed, and quality.

| Complexity | Primary Model | Fallback |
|------------|---------------|----------|
| Easy | Groq Llama 8B | OpenAI GPT-4o-mini |
| Medium | OpenAI GPT-4o | Claude Sonnet |
| Hard | Claude Sonnet | OpenAI GPT-4o |

### 2. **Cost-Optimized**
Minimizes costs, uses cheaper models.

| Complexity | Primary Model | Fallback |
|------------|---------------|----------|
| Easy | Groq Llama 8B | OpenAI GPT-4o-mini |
| Medium | Groq Llama 70B | OpenAI GPT-4o-mini |
| Hard | OpenAI GPT-4o | Claude Sonnet |

### 3. **Quality-Optimized**
Prioritizes accuracy and correctness.

| Complexity | Primary Model | Fallback |
|------------|---------------|----------|
| Easy | OpenAI GPT-4o-mini | Claude Haiku |
| Medium | Claude Sonnet | OpenAI GPT-4o |
| Hard | Claude Sonnet | OpenAI GPT-4o |

### 4. **Speed-Optimized**
Fastest possible inference.

| Complexity | Primary Model | Fallback |
|------------|---------------|----------|
| Easy | Groq Llama 8B | OpenAI GPT-4o-mini |
| Medium | Groq Llama 70B | OpenAI GPT-4o |
| Hard | OpenAI GPT-4o | Claude Sonnet |

---

## 🔄 How the Router Works

```mermaid
graph TD
    A[Upload SAS File] --> B[Analyze Complexity]
    B --> C{Score: 0-10}
    C -->|0-3| D[Easy]
    C -->|4-7| E[Medium]
    C -->|8-10| F[Hard]
    D --> G[Select Model by Strategy]
    E --> G
    F --> G
    G --> H[Call Primary Model]
    H -->|Success| I[Return Python Code]
    H -->|Failure| J[Try Fallback Model]
    J -->|Success| I
    J -->|All Fail| K[Error]
```

1. **Analyze**: Scans SAS code for complexity factors
2. **Score**: Calculates 0-10 complexity score
3. **Classify**: Maps score to Easy/Medium/Hard
4. **Route**: Selects best model based on strategy
5. **Fallback**: Retries with backup models if primary fails

---

## 🔑 API Key Configuration

### Option 1: Environment Variables (Recommended)
Create a `.env` file:
```env
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
GROQ_API_KEY=gsk_...
```

### Option 2: UI Input
Enter your Anthropic API key in the sidebar. The router will use environment variables for other providers.

---

## 📈 Cost Comparison (Approximate)

| Provider | Model | Input Cost | Output Cost | Speed |
|----------|-------|------------|-------------|-------|
| Groq | Llama 8B | $0.05/M | $0.10/M | ⚡⚡⚡ Fastest |
| OpenAI | GPT-4o-mini | $0.15/M | $0.60/M | ⚡⚡ Fast |
| Anthropic | Haiku | $0.25/M | $1.25/M | ⚡⚡ Fast |
| OpenAI | GPT-4o | $2.50/M | $10.00/M | ⚡ Medium |
| Anthropic | Sonnet | $3.00/M | $15.00/M | ⚡ Medium |

*Costs shown per 1M tokens*

---



## 🛠️ Troubleshooting

### "No providers available"
- **Cause**: No API keys configured
- **Fix**: Add at least one API key (Anthropic, OpenAI, or Groq) to `.env` or the UI

### "Conversion failed"
- **Cause**: API error or all fallbacks failed
- **Fix**: Check the "Error Details" expander for specific error message. Verify API keys are valid.

### Model not available
- **Cause**: Provider doesn't have access to the selected model
- **Fix**: Router will automatically try fallback models. No action needed.

---

