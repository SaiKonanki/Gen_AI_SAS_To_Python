# SAS to Python Converter

A Streamlit-based application to convert SAS code to Python (pandas) using LLMs (Claude, GPT, Llama) with intelligent routing and complexity analysis.

## 📂 Files to Share (Safe)

These files contain the application logic and should be shared with your team:

- **`app.py`**: The main Streamlit web application.
- **`sas_converter.py`**: Core logic for calling LLMs and handling conversion.
- **`llm_router.py`**: Intelligent router for selecting models based on code complexity.
- **`requirements.txt`**: List of Python dependencies.
- **`sas_test_suite/`**: Directory containing test SAS scripts and data.

## 🔒 Files to EXCLUDE (Sensitive)

**Do NOT share these files:**

- **`.env`**: Contains your private API keys (`ANTHROPIC_API_KEY`, etc.). Each team member should create their own `.env` file.
- **`mlruns/`**: Contains local MLFlow logs. This is generally not sensitive but can be large and is specific to your local runs.
- **`__pycache__/`**: Compiled Python files (auto-generated).

## 🚀 Setup Instructions

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure Credentials**:
   Create a `.env` file in the root directory and add your API keys:
   ```env
   ANTHROPIC_API_KEY=sk-ant-...
   # Optional:
   OPENAI_API_KEY=sk-...
   GROQ_API_KEY=gsk_...
   ```

3. **Run the App**:
   ```bash
   streamlit run app.py
   ```

## 🤖 Features

- **Multi-Provider Support**: Works with Anthropic, OpenAI, and Groq.
- **Smart Routing**: Automatically selects the best model (Haiku, Sonnet, GPT-4o, Llama 3) based on SAS complexity.
- **Complexity Analysis**: Visualizes code difficulty (Easy/Medium/Hard).
- **Validation**: Syntax checking and side-by-side output comparison.
