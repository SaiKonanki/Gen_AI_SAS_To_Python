"""
Multi-Provider LLM Router for SAS to Python Conversion

This module handles:
1. SAS code complexity analysis
2. Model selection based on complexity and routing strategy
3. Multi-provider support (Anthropic, OpenAI, Groq)
4. Smart fallback mechanisms
"""

import os
import re
from typing import Dict, Tuple, Optional, List
from anthropic import Anthropic

# Optional imports - will be checked at runtime
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    from groq import Groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False


def analyze_sas_complexity(sas_code: str) -> Dict:
    """
    Analyze SAS code complexity and return classification.
    
    Returns:
        dict: {
            'level': 'easy' | 'medium' | 'hard',
            'score': int (0-10+),
            'factors': dict of detected complexity factors
        }
    """
    score = 0
    factors = {}
    sas_lower = sas_code.lower()
    
    # 1. Check for hard features (auto-upgrade)
    hard_features = ['%macro', 'proc transpose', 'proc fcmp', 'proc format with value']
    detected_hard = [feat for feat in hard_features if feat.replace(' ', '') in sas_lower.replace(' ', '')]
    if detected_hard:
        factors['hard_features'] = detected_hard
        score += 5
    
    # 2. Count macros
    macro_count = sas_lower.count('%let') + sas_lower.count('%do') + sas_lower.count('%macro')
    if macro_count >= 3:
        score += 3
        factors['macro_count'] = macro_count
    elif macro_count >= 1:
        score += 1
        factors['macro_count'] = macro_count
    
    # 3. Code length
    lines = [line for line in sas_code.split('\n') if line.strip() and not line.strip().startswith('*')]
    line_count = len(lines)
    if line_count > 150:
        score += 3
        factors['lines'] = line_count
    elif line_count > 50:
        score += 1
        factors['lines'] = line_count
    
    # 4. SQL complexity
    if 'proc sql' in sas_lower:
        join_count = sas_lower.count('join')
        subquery_count = sas_lower.count('select') - 1  # -1 for main query
        case_count = sas_lower.count('case when')
        
        if join_count >= 3 or subquery_count >= 2 or case_count >= 3:
            score += 2
            factors['sql_complex'] = {'joins': join_count, 'subqueries': subquery_count, 'case_when': case_count}
        elif join_count >= 1 or subquery_count >= 1:
            score += 1
            factors['sql_moderate'] = {'joins': join_count, 'subqueries': subquery_count}
    
    # 5. Data operations
    merge_count = sas_lower.count('merge')
    by_count = sas_lower.count('by ')
    
    if merge_count >= 2:
        score += 2
        factors['multi_merge'] = merge_count
    elif merge_count >= 1:
        score += 1
        factors['merge'] = merge_count
    
    if 'retain' in sas_lower or 'lag(' in sas_lower:
        score += 2
        factors['advanced_data_ops'] = True
    
    if 'first.' in sas_lower or 'last.' in sas_lower:
        score += 1
        factors['first_last_processing'] = True
    
    # 6. Control flow
    if_count = sas_lower.count('if ') + sas_lower.count('if(')
    do_count = sas_lower.count('do ')
    
    if if_count >= 5 or do_count >= 3:
        score += 2
        factors['control_flow'] = {'if_statements': if_count, 'loops': do_count}
    elif if_count >= 2 or do_count >= 1:
        score += 1
        factors['control_flow'] = {'if_statements': if_count, 'loops': do_count}
    
    # 7. Array operations
    if 'array ' in sas_lower:
        array_count = sas_lower.count('array ')
        if array_count >= 2:
            score += 1
            factors['arrays'] = array_count
    
    # Normalize score to a 0‑10 scale (cap at 10)
    if score > 10:
        score = 10

    # Classify based on normalized score
    #   0‑3   → easy
    #   4‑7   → medium
    #   8‑10  → hard
    if score >= 8:
        level = 'hard'
    elif score >= 4:
        level = 'medium'
    else:
        level = 'easy'

    
    return {
        'level': level,
        'score': score,
        'factors': factors
    }


# Routing strategies with model preferences
ROUTING_STRATEGIES = {
    'balanced': {
        'easy': [
            ('groq', 'llama-3.1-8b-instant'),
            ('openai', 'gpt-4o-mini'),
            ('anthropic', 'claude-3-haiku-20240307')
        ],
        'medium': [
            ('openai', 'gpt-4o'),
            ('anthropic', 'claude-3-5-sonnet-20241022'),
            ('groq', 'llama-3.1-70b-versatile')
        ],
        'hard': [
            ('anthropic', 'claude-3-5-sonnet-20241022'),
            ('openai', 'gpt-4o'),
        ]
    },
    'cost_optimized': {
        'easy': [
            ('groq', 'llama-3.1-8b-instant'),
            ('openai', 'gpt-4o-mini'),
            ('anthropic', 'claude-3-haiku-20240307')
        ],
        'medium': [
            ('groq', 'llama-3.1-70b-versatile'),
            ('openai', 'gpt-4o-mini'),
            ('anthropic', 'claude-3-haiku-20240307')
        ],
        'hard': [
            ('openai', 'gpt-4o'),
            ('anthropic', 'claude-3-5-sonnet-20241022'),
        ]
    },
    'quality_optimized': {
        'easy': [
            ('openai', 'gpt-4o-mini'),
            ('anthropic', 'claude-3-haiku-20240307'),
            ('groq', 'llama-3.1-8b-instant')
        ],
        'medium': [
            ('anthropic', 'claude-3-5-sonnet-20241022'),
            ('openai', 'gpt-4o'),
        ],
        'hard': [
            ('anthropic', 'claude-3-5-sonnet-20241022'),
            ('openai', 'gpt-4o'),
        ]
    },
    'speed_optimized': {
        'easy': [
            ('groq', 'llama-3.1-8b-instant'),
            ('openai', 'gpt-4o-mini'),
            ('anthropic', 'claude-3-haiku-20240307')
        ],
        'medium': [
            ('groq', 'llama-3.1-70b-versatile'),
            ('openai', 'gpt-4o'),
            ('anthropic', 'claude-3-5-sonnet-20241022')
        ],
        'hard': [
            ('openai', 'gpt-4o'),
            ('anthropic', 'claude-3-5-sonnet-20241022'),
        ]
    }
}


class MultiProviderRouter:
    """
    Routes LLM requests to optimal provider based on complexity and strategy.
    """
    
    def __init__(self, strategy: str = 'balanced', api_keys: Dict[str, str] = None):
        """
        Initialize router with available providers.
        
        Args:
            strategy: one of 'balanced', 'cost_optimized', 'quality_optimized', 'speed_optimized'
            api_keys: dict of API keys {'anthropic': '...', 'openai': '...', 'groq': '...'}
        """
        self.strategy = strategy
        self.providers = {}
        api_keys = api_keys or {}
        
        # Initialize available providers
        # Check passed keys first, then environment variables
        
        anthropic_key = api_keys.get('anthropic') or os.getenv('ANTHROPIC_API_KEY')
        if anthropic_key:
            self.providers['anthropic'] = Anthropic(api_key=anthropic_key)
        
        openai_key = api_keys.get('openai') or os.getenv('OPENAI_API_KEY')
        if openai_key and OPENAI_AVAILABLE:
            self.providers['openai'] = OpenAI(api_key=openai_key)
        
        groq_key = api_keys.get('groq') or os.getenv('GROQ_API_KEY')
        if groq_key and GROQ_AVAILABLE:
            self.providers['groq'] = Groq(api_key=groq_key)
    
    def get_provider_status(self) -> Dict[str, bool]:
        """Return which providers are configured and available."""
        return {
            'anthropic': 'anthropic' in self.providers,
            'openai': 'openai' in self.providers,
            'groq': 'groq' in self.providers
        }
    
    def select_model(self, complexity: str) -> Tuple[str, str, List[Tuple[str, str]]]:
        """
        Select the best available model for the given complexity.
        
        Args:
            complexity: 'easy', 'medium', or 'hard'
        
        Returns:
            Tuple of (provider, model, fallback_chain)
        """
        candidates = ROUTING_STRATEGIES[self.strategy][complexity]
        
        # Filter to only available providers
        available_candidates = [(p, m) for p, m in candidates if p in self.providers]
        
        if not available_candidates:
            raise ValueError(f"No providers available. Please configure at least one API key.")
        
        primary_provider, primary_model = available_candidates[0]
        fallbacks = available_candidates[1:]
        
        return primary_provider, primary_model, fallbacks
    
    def call_model(self, provider: str, model: str, prompt: str, max_tokens: int = 4096) -> str:
        """
        Call the specified model with unified interface.
        
        Args:
            provider: 'anthropic', 'openai', or 'groq'
            model: model identifier
            prompt: the prompt text
            max_tokens: maximum tokens to generate
        
        Returns:
            Generated text response
        """
        if provider == 'anthropic':
            response = self.providers['anthropic'].messages.create(
                model=model,
                max_tokens=max_tokens,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0
            )
            return response.content[0].text
        
        elif provider == 'openai':
            response = self.providers['openai'].chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=max_tokens,
                temperature=0.0
            )
            return response.choices[0].message.content
        
        elif provider == 'groq':
            response = self.providers['groq'].chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=max_tokens,
                temperature=0.0
            )
            return response.choices[0].message.content
        
        else:
            raise ValueError(f"Unknown provider: {provider}")
    
    def route_with_fallback(self, complexity: str, prompt: str, max_tokens: int = 4096) -> Dict:
        """
        Route request to best model with automatic fallback on failure.
        
        Returns:
            dict: {
                'response': str,
                'provider': str,
                'model': str,
                'fallback_used': bool,
                'attempts': int
            }
        """
        provider, model, fallbacks = self.select_model(complexity)
        attempts = [(provider, model)] + fallbacks
        
        for attempt_num, (try_provider, try_model) in enumerate(attempts, 1):
            try:
                response = self.call_model(try_provider, try_model, prompt, max_tokens)
                return {
                    'response': response,
                    'provider': try_provider,
                    'model': try_model,
                    'fallback_used': attempt_num > 1,
                    'attempts': attempt_num
                }
            except Exception as e:
                # If this was the last attempt, raise the error
                if attempt_num == len(attempts):
                    raise Exception(f"All providers failed. Last error: {e}")
                # Otherwise, continue to next fallback
                continue
