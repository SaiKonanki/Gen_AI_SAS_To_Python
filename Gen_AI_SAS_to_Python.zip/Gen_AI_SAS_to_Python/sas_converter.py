import os
import glob
from pathlib import Path
from anthropic import Anthropic
from dotenv import load_dotenv
import mlflow
import time
from llm_router import analyze_sas_complexity, MultiProviderRouter

# Load environment variables
load_dotenv()

# Configuration
API_KEY = os.getenv("ANTHROPIC_API_KEY")
MODEL = "claude-3-5-haiku-latest"
INPUT_DIR = Path("sas_test_suite/sas_scripts")
OUTPUT_DIR = Path("sas_test_suite/python_scripts")
DOCS_DIR = Path("sas_test_suite/documentation")

def convert_sas_to_python(sas_code, filename, api_key=None, model=None, enable_tracking=False, 
                          use_routing=True, routing_strategy='balanced'):
    """
    Convert SAS code to Python using Anthropic API or multi-provider routing.
    
    Args:
        sas_code: SAS source code
        filename: name of the file
        api_key: Anthropic API key (for backward compatibility)
        model: specific model to use (overrides routing if provided)
        enable_tracking: whether to log to MLFlow
        use_routing: whether to use intelligent routing (default True)
        routing_strategy: 'balanced', 'cost_optimized', 'quality_optimized', 'speed_optimized'
    """
    # Use provided args or fall back to globals/env
    current_api_key = api_key or API_KEY
    current_model = model or MODEL
    
    # Analyze complexity if routing is enabled
    complexity_info = None
    if use_routing and not model:  # Don't route if specific model is requested
        complexity_info = analyze_sas_complexity(sas_code)
    
    prompt = f"""
    You are an expert SAS to Python converter. 
    Convert the following SAS code to a Python script using the pandas library.
    
    CRITICAL REQUIREMENTS:
    1. Return ONLY executable Python code. No explanations, no markdown formatting, no comments outside the code.
    2. Do NOT include markdown code fences (```python or ```). Just raw Python code.
    3. Do NOT include any introductory text like "Here's the Python equivalent" or "Key differences from SAS".
    4. The code must be immediately executable with `exec()` or `python script.py`.
    
    Code Requirements:
    1. Use pandas for data manipulation.
    2. The input CSV files are located in '../input_data/'.
    3. The output CSV files should be saved to '../generated_outputs/'.
    4. Ensure the code is complete and runnable as-is.
    5. **Documentation**:
       - Start the script with a high-level summary (docstring) explaining the business logic.
       - Target audience: Python developers who do not know SAS.
       - Explain *what* the code does (e.g., "Calculates monthly sales aggregates"), not just *how*.
       - Use Google-style docstrings.
    6. If the SAS code uses macros, convert the logic to equivalent Python functions.
    7. Include proper imports (pandas, pathlib, etc.) at the top.
    8. Ensure all file paths use the specified directories.
    
    SAS Code:
    {sas_code}
    
    Remember: Return ONLY the Python code, nothing else. The first line should be an import or a docstring.
    """
    
    start_time = time.time()
    
    try:
        python_code = None
        actual_provider = None
        actual_model = None
        input_tokens_used = None
        output_tokens_used = None

        if enable_tracking:
            mlflow.set_experiment("SAS_to_Python_Conversion")
            mlflow.start_run(run_name=f"convert_{filename}")
            mlflow.log_param("input_file", filename)
            mlflow.log_param("temperature", 0.0)
            if complexity_info:
                mlflow.log_param("complexity_level", complexity_info['level'])
                mlflow.log_param("complexity_score", complexity_info['score'])
                mlflow.log_param("routing_strategy", routing_strategy)

        # Route to appropriate model or use specified model
        if use_routing and not model and complexity_info:
            # Use router
            router = MultiProviderRouter(
                strategy=routing_strategy,
                api_keys={'anthropic': current_api_key}
            )
            result = router.route_with_fallback(
                complexity=complexity_info['level'],
                prompt=prompt,
                max_tokens=4096
            )
            
            python_code = result['response']
            actual_provider = result['provider']
            actual_model = result['model']
            fallback_used = result['fallback_used']
            input_tokens_used = result.get('input_tokens')
            output_tokens_used = result.get('output_tokens')
            
            if enable_tracking:
                mlflow.log_param("model", actual_model)
                mlflow.log_param("provider", actual_provider)
                mlflow.log_param("fallback_used", fallback_used)
                mlflow.log_param("routing_enabled", True)
        else:
            # Legacy path - use Anthropic API directly
            if not current_api_key:
                print(f"❌ Error: No API key provided for {filename}")
                return None
            
            client = Anthropic(api_key=current_api_key)
            response = client.messages.create(
                model=current_model,
                max_tokens=4096,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=0.0
            )
            
            python_code = response.content[0].text
            actual_provider = 'anthropic'
            actual_model = current_model
            input_tokens_used = response.usage.input_tokens
            output_tokens_used = response.usage.output_tokens
            
            if enable_tracking:
                mlflow.log_param("model", actual_model)
                mlflow.log_param("provider", actual_provider)
                mlflow.log_param("routing_enabled", False)

        execution_time = time.time() - start_time
        content = python_code.strip()
        
        if enable_tracking:
            mlflow.log_metric("execution_time_seconds", execution_time)
            if input_tokens_used is not None:
                mlflow.log_metric("input_token_count", input_tokens_used)
            if output_tokens_used is not None:
                mlflow.log_metric("output_token_count", output_tokens_used)
            mlflow.log_metric("error_rate", 0) # Success
            mlflow.end_run()
            
        return content
        
    except Exception as e:
        print(f"Error converting {filename}: {e}")
        if enable_tracking:
            mlflow.log_metric("error_rate", 1) # Failure
            mlflow.log_param("error_message", str(e))
            mlflow.end_run()
        # Re-raise the exception so the UI can display it
        raise e

def generate_logic_steps(sas_code, filename, api_key=None, model=None):
    """
    Generate a step-by-step logic explanation for the SAS code.
    """
    # Use provided args or fall back to globals/env
    current_api_key = api_key or API_KEY
    current_model = model or MODEL

    if not current_api_key:
        return None

    client = Anthropic(api_key=current_api_key)
    
    prompt = f"""
    Analyze the following SAS code and generate a clear, step-by-step explanation of the data transformation logic.
    
    Rules:
    1. Return a Markdown formatted list of steps.
    2. Use bolding for key actions (e.g., **Load**, **Filter**, **Join**, **Calculate**).
    3. Be concise but descriptive.
    4. Focus on the business logic and data flow.
    5. Do not include any introductory or concluding text. Just the list.
    
    Example Output:
    1. **Load Data**: Import `customers.csv` into a temporary dataset.
    2. **Filter**: Keep only rows where `status` is 'Active'.
    3. **Calculate**: Create a new column `total_value` as `price * quantity`.
    
    SAS Code:
    {sas_code}
    """
    
    try:
        response = client.messages.create(
            model=current_model,
            max_tokens=4096,
            messages=[
                {"role": "user", "content": prompt}
            ],
            temperature=0.0
        )
        return response.content[0].text.strip()
    except Exception as e:
        print(f"Error generating diagram for {filename}: {e}")
        return None


def main():
    if not API_KEY:
        print("❌ Error: ANTHROPIC_API_KEY environment variable not set.")
        print("Please export your API key: export ANTHROPIC_API_KEY='your-key-here'")
        return

    # Create output directories
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    (Path("sas_test_suite/generated_outputs")).mkdir(parents=True, exist_ok=True)
    DOCS_DIR.mkdir(parents=True, exist_ok=True)

    # Find all SAS scripts
    sas_files = sorted(list(INPUT_DIR.glob("*.sas")))
    
    if not sas_files:
        print(f"No SAS files found in {INPUT_DIR}")
        return

    print(f"Found {len(sas_files)} SAS scripts. Starting conversion using {MODEL}...\n")

    for sas_file in sas_files:
        print(f"Processing {sas_file.name}...", end=" ", flush=True)
        
        with open(sas_file, 'r') as f:
            sas_code = f.read()
            
        # 1. Convert to Python
        python_code = convert_sas_to_python(sas_code, sas_file.name)
        
        if python_code:
            # Clean up markdown code blocks if present
            if python_code.startswith("```python"):
                python_code = python_code[9:]
            if python_code.startswith("```"):
                python_code = python_code[3:]
            if python_code.endswith("```"):
                python_code = python_code[:-3]
                
            output_file = OUTPUT_DIR / sas_file.name.replace('.sas', '.py')
            with open(output_file, 'w') as f:
                f.write(python_code)
            print("✅ Code", end=" ")
        else:
            print("❌ Code", end=" ")

        # 2. Generate Diagram
        diagram_code = generate_diagram(sas_code, sas_file.name)
        
        if diagram_code:
            doc_file = DOCS_DIR / sas_file.name.replace('.sas', '.md')
            with open(doc_file, 'w') as f:
                f.write(f"# Logic Flow: {sas_file.name}\n\n")
                f.write(diagram_code)
            print("✅ Diagram")
        else:
            print("❌ Diagram")
            
        # Rate limiting pause
        time.sleep(1)

    print("\n🎉 Conversion and documentation complete!")
    print(f"Python scripts saved to: {OUTPUT_DIR}")
    print(f"Documentation saved to: {DOCS_DIR}")

if __name__ == "__main__":
    main()
