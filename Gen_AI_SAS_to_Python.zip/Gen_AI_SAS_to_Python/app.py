import streamlit as st
import os
from dotenv import load_dotenv
from pathlib import Path
from sas_converter import convert_sas_to_python, generate_logic_steps
import streamlit.components.v1 as components
import mlflow
import pandas as pd
from llm_router import MultiProviderRouter, analyze_sas_complexity

# Load environment variables
load_dotenv()

# Page Config
st.set_page_config(
    page_title="SAS to Python Converter",
    page_icon="🔄",
    layout="wide"
)

# Sidebar Configuration
with st.sidebar:
    st.header("⚙️ Configuration")
    
    # Anthropic API Key Input
    api_key = st.text_input(
        "Anthropic API Key",
        value=os.getenv("ANTHROPIC_API_KEY", ""),
        type="password",
        help="Your Claude API key from console.anthropic.com"
    )
    
    # Provider Status
    st.markdown("---")
    st.markdown("### 🔑 API Providers")
    
    # Check which providers are configured
    provider_status = {
        'Anthropic (Claude)': bool(os.getenv('ANTHROPIC_API_KEY') or api_key),
        'OpenAI (GPT)': bool(os.getenv('OPENAI_API_KEY')),
        'Groq (Llama)': bool(os.getenv('GROQ_API_KEY'))
    }
    
    for provider_name, is_configured in provider_status.items():
        if is_configured:
            st.success(provider_name)
        else:
            st.info(provider_name)
    
    # Routing Configuration
    st.markdown("---")
    st.markdown("### 🤖 Smart Routing")
    
    use_routing = st.checkbox(
        "Enable Smart Routing",
        value=True,
        help="Automatically select the best model based on code complexity"
    )
    
    if use_routing:
        routing_strategy = st.selectbox(
            "Routing Strategy",
            ["balanced", "cost_optimized", "quality_optimized", "speed_optimized"],
            help="balanced: Best overall • cost_optimized: Minimize cost • quality_optimized: Best quality • speed_optimized: Fastest"
        )
        # Model is determined by router, so no direct model selection here
        model = None # Or set a default for internal use if needed, but router will override
    else:
        routing_strategy = "balanced" # Default if routing is off, though not used
        # Model Selection (legacy mode)
        model = st.selectbox(
            "Model",
            ["claude-3-5-haiku-latest", "claude-3-5-sonnet-20241022", "claude-3-haiku-20240307"],
            index=0
        )
    
    # MLFlow Tracking Toggle
    st.markdown("---")
    enable_mlflow = st.checkbox(
        "📊 Enable MLFlow Tracking",
        value=False,
        help="Track metrics (time, tokens, errors) in local mlruns."
    )
    
    st.markdown("---")
    st.markdown("### About")
    st.markdown("Converts SAS code to Python (pandas) using multi-provider LLM routing.")

# Main Content
st.title("🔄 SAS to Python Converter")
st.markdown("Upload your SAS script below to convert it to Python pandas code.")

uploaded_file = st.file_uploader("Choose a SAS file", type=['sas'])

if uploaded_file is not None:
    # Read file content
    sas_code = uploaded_file.getvalue().decode("utf-8")
    filename = uploaded_file.name
    
    # Show original code preview
    with st.expander("View Input SAS Code", expanded=False):
        st.code(sas_code, language="sas")
    
    # Analyze complexity and show preview
    if use_routing:
        complexity_info = analyze_sas_complexity(sas_code)
        
        # Complexity badge
        complexity_colors = {
            'easy': '🟢',
            'medium': '🟡',
            'hard': '🔴'
        }
        complexity_labels = {
            'easy': 'Easy',
            'medium': 'Medium',
            'hard': 'Hard'
        }
        
        st.markdown(f"### {complexity_colors[complexity_info['level']]} Complexity: **{complexity_labels[complexity_info['level']]}** (Score: {complexity_info['score']})")
        
        with st.expander("📊 Complexity Analysis"):
            st.markdown(f"**Level**: {complexity_info['level'].upper()}")
            st.markdown(f"**Score**: {complexity_info['score']}")
            if complexity_info['factors']:
                st.markdown("**Detected Factors**:")
                for factor, value in complexity_info['factors'].items():
                    st.markdown(f"- {factor}: {value}")

    # Initialize Session State
    if 'python_code' not in st.session_state:
        st.session_state['python_code'] = None
        st.session_state['logic_steps'] = None

    if st.button("🚀 Convert to Python", type="primary"):
        # Clear previous results to prevent mixed UI state
        st.session_state['python_code'] = None
        st.session_state['logic_steps'] = None
        
        if not api_key and not use_routing:
            st.error("Please provide an API Key in the sidebar or .env file.")
        else:
            with st.spinner("Converting... This may take a few seconds."):
                try:
                    # 1. Convert Code (with routing)
                    python_code = convert_sas_to_python(
                        sas_code, 
                        filename, 
                        api_key=api_key, 
                        model=model, 
                        enable_tracking=enable_mlflow,
                        use_routing=use_routing,
                        routing_strategy=routing_strategy
                    )
                    
                    # 2. Generate Logic Steps
                    logic_steps = generate_logic_steps(sas_code, filename, api_key=api_key, model=model)
                    
                    if python_code:
                        st.session_state['python_code'] = python_code
                        st.session_state['logic_steps'] = logic_steps
                        st.session_state['sas_filename'] = filename
                        st.rerun()
                except Exception as e:
                    st.error(f"❌ Conversion Failed: {str(e)}")
                    with st.expander("🔍 Error Details"):
                        st.code(str(e))

    if st.session_state.get('python_code'):
        python_code = st.session_state['python_code']
        logic_steps = st.session_state.get('logic_steps')
        
        st.success("Conversion Complete!")
                    
        # Create Tabs
        tab_val, tab_code, tab_logic, tab_mlflow = st.tabs(["✅ Validation", "💻 Code Comparison", "📊 Logic Flow", "📈 MLFlow Metrics"])
    
        with tab_code:
            col1, col2 = st.columns(2)
        
            with col1:
                st.subheader("SAS (Original)")
                st.code(sas_code, language="sas")
            
            with col2:
                st.subheader("Python (Converted)")
                # Clean up markdown if present
                display_code = python_code
                if display_code.startswith("```python"):
                    display_code = display_code[9:]
                if display_code.startswith("```"):
                    display_code = display_code[3:]
                if display_code.endswith("```"):
                    display_code = display_code[:-3]
                
                st.code(display_code, language="python")
            
                # Download Button
                st.download_button(
                    label="📥 Download Python Script",
                    data=display_code,
                    file_name=filename.replace('.sas', '.py'),
                    mime="text/x-python"
                )
    
        with tab_logic:
            st.subheader("Logic Steps")
            if logic_steps:
                st.markdown(logic_steps)
            else:
                st.warning("Could not generate logic steps.")
    
        with tab_mlflow:
            st.subheader("MLFlow Tracking Metrics")
        
            if enable_mlflow:
                try:
                    # Get the experiment
                    experiment = mlflow.get_experiment_by_name("SAS_to_Python_Conversion")
                
                    if experiment:
                        # Search for runs in this experiment
                        runs_df = mlflow.search_runs(
                            experiment_ids=[experiment.experiment_id],
                            order_by=["start_time DESC"],
                            max_results=10
                        )
                    
                        if not runs_df.empty:
                            st.success(f"Found {len(runs_df)} recent runs")
                        
                            # Display key metrics
                            st.markdown("### Recent Conversions")
                        
                            # Select relevant columns
                            display_cols = []
                            for col in runs_df.columns:
                                if col.startswith('params.') or col.startswith('metrics.') or col == 'start_time':
                                    display_cols.append(col)
                        
                            if display_cols:
                                # Clean up column names for display
                                display_df = runs_df[display_cols].copy()
                                display_df.columns = [col.replace('params.', '').replace('metrics.', '') for col in display_df.columns]
                            
                                st.dataframe(display_df, use_container_width=True)
                            
                                # Show metrics charts
                                st.markdown("### Metrics Over Time")
                            
                                col1, col2 = st.columns(2)
                            
                                with col1:
                                    if 'execution_time_seconds' in display_df.columns:
                                        st.line_chart(display_df['execution_time_seconds'])
                                        st.caption("Execution Time (seconds)")
                            
                                with col2:
                                    if 'input_token_count' in display_df.columns and 'output_token_count' in display_df.columns:
                                        token_df = display_df[['input_token_count', 'output_token_count']]
                                        st.line_chart(token_df)
                                        st.caption("Token Usage")
                            
                                # Calculate total cost
                                st.markdown("---")
                                st.markdown("## 💰 Total Cost Incurred")
                            
                                if 'input_token_count' in display_df.columns and 'output_token_count' in display_df.columns and 'model' in display_df.columns:
                                    # Anthropic Claude pricing (as of Nov 2024)
                                    # Haiku: $0.25 per MTok input, $1.25 per MTok output
                                    # Sonnet: $3.00 per MTok input, $15.00 per MTok output
                                
                                    total_cost = 0.0
                                    for idx, row in display_df.iterrows():
                                        input_tokens = row.get('input_token_count', 0)
                                        output_tokens = row.get('output_token_count', 0)
                                        model = row.get('model', '')
                                    
                                        if 'haiku' in model.lower():
                                            cost = (input_tokens / 1_000_000 * 0.25) + (output_tokens / 1_000_000 * 1.25)
                                        elif 'sonnet' in model.lower():
                                            cost = (input_tokens / 1_000_000 * 3.00) + (output_tokens / 1_000_000 * 15.00)
                                        else:
                                            cost = 0.0  # Unknown model
                                    
                                        total_cost += cost
                                
                                    # Display in a prominent way
                                    st.markdown(f"### ${total_cost:.2f}")
                                    st.caption(f"Based on {len(display_df)} conversion(s)")
                                
                                    # Breakdown by model
                                    if 'model' in display_df.columns:
                                        st.markdown("**Cost Breakdown by Model:**")
                                        for model_name in display_df['model'].unique():
                                            model_rows = display_df[display_df['model'] == model_name]
                                            model_cost = 0.0
                                            for idx, row in model_rows.iterrows():
                                                input_tokens = row.get('input_token_count', 0)
                                                output_tokens = row.get('output_token_count', 0)
                                            
                                                if 'haiku' in model_name.lower():
                                                    model_cost += (input_tokens / 1_000_000 * 0.25) + (output_tokens / 1_000_000 * 1.25)
                                                elif 'sonnet' in model_name.lower():
                                                    model_cost += (input_tokens / 1_000_000 * 3.00) + (output_tokens / 1_000_000 * 15.00)
                                        
                                            st.text(f"• {model_name}: ${model_cost:.2f}")
                                else:
                                    st.info("Cost data not available. Enable tracking and run conversions to see costs.")
                            
                                st.markdown("---")
                            
                                # Summary stats
                                st.markdown("### Summary Statistics")
                                if 'execution_time_seconds' in display_df.columns:
                                    avg_time = display_df['execution_time_seconds'].mean()
                                    st.metric("Average Execution Time", f"{avg_time:.2f}s")
                            
                                if 'error_rate' in display_df.columns:
                                    error_rate = display_df['error_rate'].mean() * 100
                                    st.metric("Error Rate", f"{error_rate:.1f}%")
                            else:
                                st.info("No metrics data available yet.")
                        else:
                            st.info("No runs found yet. Enable MLFlow tracking and run a conversion.")
                    else:
                        st.info("No MLFlow experiment found yet. Enable tracking and run a conversion.")
                    
                except Exception as e:
                    st.error(f"Error loading MLFlow data: {e}")
            else:
                st.info("⚠️ MLFlow tracking is currently disabled. Enable it in the sidebar to see metrics.")
                st.markdown("""
                To view metrics:
                1. Check "📊 Enable MLFlow Tracking" in the sidebar
                2. Run a conversion
                3. Return to this tab to see the results
                """)
        with tab_val:
            st.subheader("Validation Dashboard")
            
            # Code Validity Check (Syntax)
            try:
                compile(python_code, '<string>', 'exec')
                st.success("Code Syntax is Valid. Ready to run.")
            except SyntaxError as e:
                st.error(f"Syntax Error: {e}")
            except Exception as e:
                st.warning(f"Could not verify syntax: {e}")
        
            # Split Pane Layout
            gen_col, ref_col = st.columns(2)
        
            # --- Left Column: Generated Data ---
            with gen_col:
                st.markdown("### 🐍 Generated Data (Python)")
                
                # Show current file context
                if 'sas_filename' in st.session_state:
                    st.caption(f"Source: {st.session_state['sas_filename']}")
                
                if st.button("▶️ Run Python Code", use_container_width=True):
                    try:
                        # Clear previous output
                        if 'gen_df' in st.session_state:
                            del st.session_state['gen_df']
                        if 'gen_file' in st.session_state:
                            del st.session_state['gen_file']
                        
                        # Extract expected output filename from the Python code
                        # Look for patterns like: df.to_csv('path/output_XX.csv') or to_csv("path", ...)
                        import re
                        # Try multiple patterns
                        patterns = [
                            r"\.to_csv\s*\(\s*['\"]([^'\"]+\.csv)['\"]",  # .to_csv('file.csv')
                            r"\.to_csv\s*\(\s*['\"]([^'\"]+)['\"]",  # .to_csv('path')
                            r"to_csv\s*\(\s*['\"]([^'\"]+\.csv)['\"]",  # to_csv('file.csv')
                        ]
                        
                        expected_output_file = None
                        # Try multiple patterns
                        patterns = [
                            r"\.to_csv\s*\(\s*['\"]([^'\"]+\.csv)['\"]",  # .to_csv('file.csv')
                            r"to_csv\s*\(\s*['\"]([^'\"]+\.csv)['\"]",    # to_csv('file.csv')
                            r"['\"]([^'\"]+\.csv)['\"]",                   # Any 'file.csv' string (fallback)
                        ]
                        
                        expected_output_file = None
                        for pattern in patterns:
                            matches = re.findall(pattern, python_code)
                            if matches:
                                # Get the last match (usually the final output)
                                output_path = matches[-1]
                                expected_output_file = Path(output_path).name
                                st.info(f"📝 Expected output file: `{expected_output_file}`")
                                break
                        
                        if not expected_output_file:
                            st.warning("Could not detect specific output filename. Checking for most recent file.")
                        
                        # Show what we're executing
                        st.info("Executing converted Python code...")
                        
                        # PATCH: Fix file paths for execution context
                        # Replace all occurrences of '../input_data' and '../generated_outputs'
                        # This handles: Path('../input_data'), '../input_data/file.csv', etc.
                        code_to_run = python_code.replace('../input_data', 'sas_test_suite/input_data')
                        code_to_run = code_to_run.replace('../generated_outputs', 'sas_test_suite/generated_outputs')
                        
                        with st.expander("📝 Code Being Executed", expanded=False):
                            st.code(code_to_run, language="python")
                        
                        # Capture stdout
                        import sys
                        from io import StringIO
                        old_stdout = sys.stdout
                        redirected_output = sys.stdout = StringIO()
                    
                        # Execute the converted Python code
                        exec_globals = {}
                        exec(code_to_run, exec_globals)
                    
                        sys.stdout = old_stdout
                        
                        # Show execution logs
                        logs = redirected_output.getvalue()
                        if logs:
                            with st.expander("📋 Execution Logs"):
                                st.text(logs)
                    
                        # Check for generated output files
                        output_dir = Path("sas_test_suite/generated_outputs")
                        if output_dir.exists():
                            files = list(output_dir.glob("*.csv"))
                            if files:
                                # If we know the expected filename, look for it specifically
                                target_file = None
                                if expected_output_file:
                                    target_file = output_dir / expected_output_file
                                    if not target_file.exists():
                                        st.warning(f"Expected file `{expected_output_file}` not found. Using most recent file instead.")
                                        target_file = None
                                
                                # Fall back to most recently modified if we don't have a specific target
                                if target_file is None:
                                    target_file = max(files, key=os.path.getmtime)
                                
                                # Show all files and which one we picked
                                with st.expander("🔍 Available Output Files"):
                                    for f in sorted(files, key=os.path.getmtime, reverse=True):
                                        mtime = os.path.getmtime(f)
                                        is_target = f == target_file
                                        st.text(f"{'✅' if is_target else '  '} {f.name} (modified: {pd.Timestamp.fromtimestamp(mtime)})")
                                
                                # Load generated dataframe
                                gen_df = pd.read_csv(target_file)
                                st.session_state['gen_df'] = gen_df
                                st.session_state['gen_file'] = target_file.name
                                st.success(f"✅ Loaded: {target_file.name}")
                            else:
                                st.warning("No output CSV found in generated_outputs directory.")
                        else:
                            st.error(f"Output directory not found: {output_dir}")
                    
                    except Exception as e:
                        sys.stdout = old_stdout
                        st.error(f"❌ Execution Failed: {e}")
                        import traceback
                        with st.expander("🐛 Error Details"):
                            st.code(traceback.format_exc())
            
            
                if 'gen_df' in st.session_state:
                    df = st.session_state['gen_df']
                    file_name = st.session_state.get('gen_file', 'unknown')
                    st.success(f"📄 {file_name} | Rows: {df.shape[0]} | Cols: {df.shape[1]}")
                    st.dataframe(df.head(), use_container_width=True)
                else:
                    st.info("Run code to generate data.")

            # --- Right Column: Reference Data ---
            with ref_col:
                st.markdown("### 💾 Reference Data (SAS)")
                uploaded_sas_output = st.file_uploader("Upload Expected Output (CSV)", type=["csv"])
            
                if uploaded_sas_output is not None:
                    try:
                        exp_df = pd.read_csv(uploaded_sas_output)
                        st.session_state['exp_df'] = exp_df
                        st.success(f"Rows: {exp_df.shape[0]} | Cols: {exp_df.shape[1]}")
                        st.dataframe(exp_df.head(), use_container_width=True)
                    except Exception as e:
                        st.error(f"Error reading file: {e}")
                else:
                    st.info("Upload CSV to compare.")

            # --- Bottom Section: Comparison Report ---
            st.markdown("---")
            st.subheader("📊 Comparison Report")
        
            if 'gen_df' in st.session_state and 'exp_df' in st.session_state:
                gen_df = st.session_state['gen_df']
                exp_df = st.session_state['exp_df']
            
                # Normalize
                gen_df.columns = gen_df.columns.str.lower()
                exp_df.columns = exp_df.columns.str.lower()
            
                # Metrics
                m1, m2, m3 = st.columns(3)
                row_diff = gen_df.shape[0] - exp_df.shape[0]
                col_diff = gen_df.shape[1] - exp_df.shape[1]
            
                m1.metric("Row Count", gen_df.shape[0], delta=row_diff, delta_color="inverse" if row_diff != 0 else "off")
                m2.metric("Column Count", gen_df.shape[1], delta=col_diff, delta_color="inverse" if col_diff != 0 else "off")
            
                # Detailed Comparison
                if st.button("🔍 Run Detailed Comparison", use_container_width=True):
                    try:
                        # Align rows
                        sort_col = gen_df.columns[0]
                        gen_df_sorted = gen_df.sort_values(by=sort_col).reset_index(drop=True)
                        exp_df_sorted = exp_df.sort_values(by=sort_col).reset_index(drop=True)
                    
                        # Compare
                        diff = gen_df_sorted.compare(exp_df_sorted)
                    
                        if diff.empty:
                            st.balloons()
                            st.success("✅ Perfect Match! The Python output is identical to the SAS output.")
                            m3.metric("Status", "Match", delta="Perfect", delta_color="normal")
                        else:
                            st.error(f"❌ Differences Found: {len(diff)} rows mismatch")
                            m3.metric("Status", "Mismatch", delta=f"-{len(diff)} rows", delta_color="inverse")
                            st.dataframe(diff, use_container_width=True)
                            st.caption("Showing differences: 'self' is Python, 'other' is SAS")
                    except Exception as e:
                        st.error(f"Comparison Error: {e}")
            else:
                st.info("Load both datasets to view comparison report.")

