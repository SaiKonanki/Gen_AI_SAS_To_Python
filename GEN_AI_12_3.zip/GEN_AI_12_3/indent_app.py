import sys

filename = '/Users/saicharankonanki/Downloads/sas_to_python_poc/app.py'
with open(filename, 'r') as f:
    lines = f.readlines()

# Find the line starting with "# Create Tabs"
start_line = -1
for i, line in enumerate(lines):
    if line.strip() == "# Create Tabs":
        start_line = i
        break

if start_line != -1:
    # Indent from start_line to end
    new_lines = lines[:start_line]
    for line in lines[start_line:]:
        if line.strip() != '':
            new_lines.append('    ' + line)
        else:
            new_lines.append(line)
    
    with open(filename, 'w') as f:
        f.writelines(new_lines)
    print("Indented successfully")
else:
    print("Start line not found")
