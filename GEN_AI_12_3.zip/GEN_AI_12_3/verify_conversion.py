import pandas as pd
import glob
import os
import subprocess
from pathlib import Path
import sys

# Configuration
PYTHON_SCRIPTS_DIR = Path("sas_test_suite/python_scripts")
GENERATED_OUTPUTS_DIR = Path("sas_test_suite/generated_outputs")
EXPECTED_OUTPUTS_DIR = Path("sas_test_suite/expected_outputs")

def run_python_script(script_path):
    """Run the converted Python script."""
    print(f"Running {script_path.name}...", end=" ", flush=True)
    try:
        # Run script in its directory context so relative paths work
        subprocess.check_call([sys.executable, script_path.resolve()], cwd=PYTHON_SCRIPTS_DIR)
        print("✅ Executed")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Execution Failed: {e}")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def compare_outputs(test_name):
    """Compare generated output with expected output."""
    # Map test name to output file name (e.g., test_01_... -> output_01.csv)
    # Assuming naming convention: test_XX_... -> output_XX.csv
    try:
        test_num = test_name.split('_')[1]
        output_filename = f"output_{test_num}.csv"
    except IndexError:
        print(f"⚠️ Could not parse test number from {test_name}")
        return False

    generated_file = GENERATED_OUTPUTS_DIR / output_filename
    expected_file = EXPECTED_OUTPUTS_DIR / output_filename

    if not generated_file.exists():
        print(f"   ❌ Missing generated output: {output_filename}")
        return False
    
    if not expected_file.exists():
        print(f"   ⚠️ Missing expected output: {output_filename}")
        return False

    try:
        gen_df = pd.read_csv(generated_file)
        exp_df = pd.read_csv(expected_file)
        
        # Normalize column names (lowercase)
        gen_df.columns = gen_df.columns.str.lower()
        exp_df.columns = exp_df.columns.str.lower()
        
        # Sort by key columns if possible to ensure order doesn't matter
        # This is a heuristic; might need adjustment for specific tests
        if 'customer_id' in gen_df.columns:
            gen_df = gen_df.sort_values('customer_id').reset_index(drop=True)
            exp_df = exp_df.sort_values('customer_id').reset_index(drop=True)
        elif 'product_id' in gen_df.columns:
            gen_df = gen_df.sort_values('product_id').reset_index(drop=True)
            exp_df = exp_df.sort_values('product_id').reset_index(drop=True)
            
        # Compare with tolerance for floats
        pd.testing.assert_frame_equal(gen_df, exp_df, check_dtype=False, atol=0.01)
        print(f"   ✅ Output Matches {output_filename}")
        return True
    except AssertionError as e:
        print(f"   ❌ Output Mismatch {output_filename}")
        print(f"   Details: {e}")
        return False
    except Exception as e:
        print(f"   ❌ Comparison Error: {e}")
        return False

def main():
    print("="*60)
    print("SAS to Python Conversion - Verification")
    print("="*60)
    
    scripts = sorted(list(PYTHON_SCRIPTS_DIR.glob("*.py")))
    
    if not scripts:
        print(f"No Python scripts found in {PYTHON_SCRIPTS_DIR}")
        print("Did you run sas_converter.py?")
        return

    results = []
    
    for script in scripts:
        print(f"\nTest Case: {script.stem}")
        
        # 1. Run Script
        execution_success = run_python_script(script)
        
        # 2. Compare Outputs
        if execution_success:
            comparison_success = compare_outputs(script.stem)
        else:
            comparison_success = False
            
        results.append({
            "test": script.stem,
            "execution": execution_success,
            "comparison": comparison_success
        })

    # Summary Report
    print("\n" + "="*60)
    print("FINAL REPORT")
    print("="*60)
    print(f"{'Test Case':<40} | {'Exec':<10} | {'Result':<10}")
    print("-" * 66)
    
    passed = 0
    report_lines = []
    report_lines.append("# SAS to Python Conversion Verification Report")
    report_lines.append(f"**Total Tests:** {len(results)}")
    report_lines.append("")
    report_lines.append("| Test Case | Execution | Result |")
    report_lines.append("| :--- | :--- | :--- |")

    for r in results:
        exec_status = "PASS" if r['execution'] else "FAIL"
        comp_status = "MATCH" if r['comparison'] else "MISMATCH"
        if not r['execution']: comp_status = "-"
        
        print(f"{r['test']:<40} | {exec_status:<10} | {comp_status:<10}")
        report_lines.append(f"| {r['test']} | {exec_status} | {comp_status} |")
        
        if r['execution'] and r['comparison']:
            passed += 1
            
    print("-" * 66)
    print(f"Total Tests: {len(results)}")
    print(f"Passed:      {passed}")
    print(f"Failed:      {len(results) - passed}")
    print(f"Success Rate: {(passed/len(results))*100:.1f}%")

    report_lines.append("")
    report_lines.append(f"**Passed:** {passed}")
    report_lines.append(f"**Failed:** {len(results) - passed}")
    report_lines.append(f"**Success Rate:** {(passed/len(results))*100:.1f}%")

    report_path = Path("sas_test_suite/verification_report.md")
    with open(report_path, "w") as f:
        f.write("\n".join(report_lines))
    print(f"\n📄 Report saved to: {report_path}")

if __name__ == "__main__":
    main()
