from sas_converter import convert_sas_to_python
import mlflow
import os
import shutil

# Clean up previous runs
if os.path.exists("mlruns"):
    shutil.rmtree("mlruns")

sas_code = """
data work.test;
    set sashelp.class;
    bmi = weight / (height * height) * 703;
run;
"""

print("Running conversion with MLFlow tracking...")
python_code = convert_sas_to_python(sas_code, "test_mlflow.sas", enable_tracking=True)

if python_code:
    print("✅ Conversion successful")
else:
    print("❌ Conversion failed")

if os.path.exists("mlruns"):
    print("✅ mlruns directory created")
    # List experiments
    client = mlflow.tracking.MlflowClient()
    experiments = client.search_experiments()
    for exp in experiments:
        print(f"Experiment: {exp.name}")
        runs = client.search_runs(exp.experiment_id)
        for run in runs:
            print(f"  Run ID: {run.info.run_id}")
            print(f"  Metrics: {run.data.metrics}")
            print(f"  Params: {run.data.params}")
else:
    print("❌ mlruns directory NOT created")
